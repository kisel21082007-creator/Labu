def hello(name):
    return f"Привет, {name}!"

