#1
from math import*
x=4
print(sqrt(x))

#2
from datetime import datetime
now = datetime.now()
print("текущее время:",now)