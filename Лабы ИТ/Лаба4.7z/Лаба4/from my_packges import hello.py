from my_packges import hello
print(hello("Антон"))
