def greet(name):
    return f"Привет, {name}!"
